-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2022. Júl 20. 13:02
-- Kiszolgáló verziója: 10.4.21-MariaDB
-- PHP verzió: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `pizza`
--

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `orders`
--

CREATE TABLE `orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `shipping_price` int(11) NOT NULL,
  `delivery_method` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- A tábla adatainak kiíratása `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `shipping_price`, `delivery_method`, `total`, `created_at`, `updated_at`) VALUES
(3, 5, 1000, 'kiszallitas', 2500, '2021-12-01 16:50:19', '2021-12-03 16:50:23'),
(4, 5, 0, 'szemelyes', 10400, '2021-12-03 17:34:24', '2021-12-03 17:37:12'),
(5, 9, 1000, 'kiszallitas', 2600, '2021-12-21 17:19:20', NULL),
(6, 10, 0, 'szemelyes', 2600, '2021-12-21 17:20:43', NULL),
(7, 11, 1000, 'kiszallitas', 2200, '2021-12-30 16:43:35', NULL),
(8, 12, 1000, 'kiszallitas', 2200, '2021-12-30 16:43:38', NULL),
(9, 13, 1000, 'kiszallitas', 2200, '2021-12-30 16:43:47', NULL),
(10, 14, 1000, 'kiszallitas', 2200, '2021-12-30 16:43:48', NULL),
(11, 15, 1000, 'kiszallitas', 2200, '2021-12-30 16:43:48', NULL),
(12, 16, 1000, 'kiszallitas', 2200, '2021-12-30 16:43:48', NULL),
(13, 17, 0, 'szemelyes', 2200, '2021-12-30 16:43:52', NULL),
(14, 18, 1000, 'kiszallitas', 2200, '2021-12-30 16:44:18', NULL),
(15, 19, 1000, 'kiszallitas', 2200, '2021-12-30 16:44:25', NULL),
(16, 20, 1000, 'kiszallitas', 2200, '2021-12-30 16:44:26', NULL),
(17, 21, 1000, 'kiszallitas', 2200, '2021-12-30 16:44:26', NULL),
(18, 22, 1000, 'kiszallitas', 2200, '2021-12-30 16:44:27', NULL),
(19, 23, 1000, 'kiszallitas', 2200, '2021-12-30 16:44:27', NULL),
(20, 24, 1000, 'kiszallitas', 2200, '2021-12-30 16:44:29', NULL),
(21, 25, 1000, 'kiszallitas', 4300, '2021-12-30 16:49:13', NULL),
(22, 26, 1000, 'kiszallitas', 4300, '2021-12-30 16:49:14', NULL),
(23, 27, 1000, 'kiszallitas', 4300, '2021-12-30 16:49:29', NULL),
(24, 28, 1000, 'kiszallitas', 4300, '2021-12-30 16:50:55', NULL),
(25, 29, 1000, 'kiszallitas', 4300, '2021-12-30 16:51:44', NULL),
(26, 30, 0, 'szemelyes', 4300, '2021-12-30 16:52:47', NULL),
(27, 31, 0, 'szemelyes', 4300, '2021-12-30 16:53:09', NULL),
(28, 32, 0, 'szemelyes', 4300, '2021-12-30 16:57:11', NULL),
(29, 33, 0, 'szemelyes', 2500, '2022-07-20 10:19:39', NULL),
(30, 34, 0, 'szemelyes', 2500, '2022-07-20 10:19:43', NULL),
(31, 35, 0, 'szemelyes', 2500, '2022-07-20 10:19:50', NULL),
(32, 36, 1000, 'kiszallitas', 2500, '2022-07-20 10:20:11', NULL),
(33, 37, 1000, 'kiszallitas', 2500, '2022-07-20 10:20:12', NULL),
(34, 38, 1000, 'kiszallitas', 2500, '2022-07-20 10:20:12', NULL),
(35, 39, 1000, 'kiszallitas', 2500, '2022-07-20 10:20:12', NULL),
(36, 40, 0, 'szemelyes', 2500, '2022-07-20 10:20:28', NULL),
(37, 41, 0, 'szemelyes', 2500, '2022-07-20 10:20:28', NULL),
(38, 42, 0, 'szemelyes', 2500, '2022-07-20 10:20:29', NULL),
(39, 43, 0, 'szemelyes', 2500, '2022-07-20 10:20:29', NULL),
(40, 44, 0, 'szemelyes', 2500, '2022-07-20 10:20:29', NULL),
(41, 45, 0, 'szemelyes', 2500, '2022-07-20 10:20:29', NULL),
(42, 46, 0, 'szemelyes', 2500, '2022-07-20 10:20:30', NULL),
(43, 47, 0, 'szemelyes', 2500, '2022-07-20 10:20:30', NULL),
(44, 48, 0, 'szemelyes', 2500, '2022-07-20 10:20:31', NULL),
(45, 49, 1000, 'kiszallitas', 2500, '2022-07-20 10:20:43', NULL),
(46, 50, 1000, 'kiszallitas', 2500, '2022-07-20 10:20:43', NULL),
(47, 51, 1000, 'kiszallitas', 2500, '2022-07-20 10:20:44', NULL),
(48, 52, 0, 'szemelyes', 2500, '2022-07-20 10:22:49', NULL),
(49, 53, 0, 'szemelyes', 2500, '2022-07-20 10:22:50', NULL),
(50, 54, 0, 'szemelyes', 2500, '2022-07-20 10:22:50', NULL),
(51, 55, 0, 'szemelyes', 2500, '2022-07-20 10:22:52', NULL),
(52, 56, 0, 'szemelyes', 2500, '2022-07-20 10:22:52', NULL),
(53, 57, 0, 'szemelyes', 2500, '2022-07-20 10:22:53', NULL),
(54, 58, 0, 'szemelyes', 2500, '2022-07-20 10:22:53', NULL),
(55, 59, 1000, 'kiszallitas', 2500, '2022-07-20 10:23:16', NULL),
(56, 60, 1000, 'kiszallitas', 2500, '2022-07-20 10:23:22', NULL),
(57, 61, 1000, 'kiszallitas', 2500, '2022-07-20 10:23:29', NULL),
(58, 62, 1000, 'kiszallitas', 2500, '2022-07-20 10:23:29', NULL),
(59, 63, 1000, 'kiszallitas', 2500, '2022-07-20 10:23:30', NULL),
(60, 65, 0, 'szemelyes', 2500, '2022-07-20 10:31:15', NULL),
(61, 66, 0, 'szemelyes', 2500, '2022-07-20 10:31:16', NULL);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `order_pizzas`
--

CREATE TABLE `order_pizzas` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `pizza_id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `pizza_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `topping_list` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`topping_list`)),
  `size` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `subtotal` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- A tábla adatainak kiíratása `order_pizzas`
--

INSERT INTO `order_pizzas` (`id`, `pizza_id`, `order_id`, `pizza_name`, `topping_list`, `size`, `price`, `quantity`, `subtotal`, `created_at`, `updated_at`) VALUES
(0, 4, 1, 'Magyaros', '[{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"9\",\"name\":\"Kolbu00e1sz\",\"created_at\":null,\"updated_at\":null},{\"id\":\"7\",\"name\":\"Bacon\",\"created_at\":null,\"updated_at\":null},{\"id\":\"8\",\"name\":\"Paradicsom\",\"created_at\":null,\"updated_at\":null},{\"id\":\"10\",\"name\":\"Csemegeuborka\",\"created_at\":null,\"updated_at\":null}]', 'Normál', 2500, 10, 25000, NULL, NULL),
(0, 1, 2, 'Suprame', '[{\"id\":\"3\",\"name\":\"Szalu00e1mi\",\"created_at\":null,\"updated_at\":null},{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null}]', 'Normál', 2300, 2, 4600, NULL, NULL),
(0, 4, 3, 'Magyaros', '[{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"9\",\"name\":\"Kolbu00e1sz\",\"created_at\":null,\"updated_at\":null},{\"id\":\"7\",\"name\":\"Bacon\",\"created_at\":null,\"updated_at\":null},{\"id\":\"8\",\"name\":\"Paradicsom\",\"created_at\":null,\"updated_at\":null},{\"id\":\"10\",\"name\":\"Csemegeuborka\",\"created_at\":null,\"updated_at\":null}]', 'Normál', 2500, 1, 2500, NULL, NULL),
(0, 3, 4, 'Songoku', '[{\"id\":\"2\",\"name\":\"Sonka\",\"created_at\":null,\"updated_at\":null},{\"id\":\"6\",\"name\":\"Gomba\",\"created_at\":null,\"updated_at\":null},{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"11\",\"name\":\"Kukorica\",\"created_at\":null,\"updated_at\":null}]', 'Normál', 2600, 4, 10400, '2021-12-03 17:34:24', NULL),
(0, 3, 5, 'Songoku', '[{\"id\":\"2\",\"name\":\"Sonka\",\"created_at\":null,\"updated_at\":null},{\"id\":\"6\",\"name\":\"Gomba\",\"created_at\":null,\"updated_at\":null},{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"11\",\"name\":\"Kukorica\",\"created_at\":null,\"updated_at\":null}]', 'Normál', 2600, 1, 2600, '2021-12-21 17:19:20', NULL),
(0, 3, 6, 'Songoku', '[{\"id\":\"2\",\"name\":\"Sonka\",\"created_at\":null,\"updated_at\":null},{\"id\":\"6\",\"name\":\"Gomba\",\"created_at\":null,\"updated_at\":null},{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"11\",\"name\":\"Kukorica\",\"created_at\":null,\"updated_at\":null}]', 'Normál', 2600, 1, 2600, '2021-12-21 17:20:43', NULL),
(0, 2, 7, 'Mexicoi', '[{\"id\":\"5\",\"name\":\"Bab\",\"created_at\":null,\"updated_at\":null},{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"4\",\"name\":\"Csirke\",\"created_at\":null,\"updated_at\":null}]', 'Normál', 2200, 1, 2200, '2021-12-30 16:43:35', NULL),
(0, 2, 8, 'Mexicoi', '[{\"id\":\"5\",\"name\":\"Bab\",\"created_at\":null,\"updated_at\":null},{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"4\",\"name\":\"Csirke\",\"created_at\":null,\"updated_at\":null}]', 'Normál', 2200, 1, 2200, '2021-12-30 16:43:38', NULL),
(0, 2, 9, 'Mexicoi', '[{\"id\":\"5\",\"name\":\"Bab\",\"created_at\":null,\"updated_at\":null},{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"4\",\"name\":\"Csirke\",\"created_at\":null,\"updated_at\":null}]', 'Normál', 2200, 1, 2200, '2021-12-30 16:43:47', NULL),
(0, 2, 10, 'Mexicoi', '[{\"id\":\"5\",\"name\":\"Bab\",\"created_at\":null,\"updated_at\":null},{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"4\",\"name\":\"Csirke\",\"created_at\":null,\"updated_at\":null}]', 'Normál', 2200, 1, 2200, '2021-12-30 16:43:48', NULL),
(0, 2, 11, 'Mexicoi', '[{\"id\":\"5\",\"name\":\"Bab\",\"created_at\":null,\"updated_at\":null},{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"4\",\"name\":\"Csirke\",\"created_at\":null,\"updated_at\":null}]', 'Normál', 2200, 1, 2200, '2021-12-30 16:43:48', NULL),
(0, 2, 12, 'Mexicoi', '[{\"id\":\"5\",\"name\":\"Bab\",\"created_at\":null,\"updated_at\":null},{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"4\",\"name\":\"Csirke\",\"created_at\":null,\"updated_at\":null}]', 'Normál', 2200, 1, 2200, '2021-12-30 16:43:48', NULL),
(0, 2, 13, 'Mexicoi', '[{\"id\":\"5\",\"name\":\"Bab\",\"created_at\":null,\"updated_at\":null},{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"4\",\"name\":\"Csirke\",\"created_at\":null,\"updated_at\":null}]', 'Normál', 2200, 1, 2200, '2021-12-30 16:43:52', NULL),
(0, 2, 14, 'Mexicoi', '[{\"id\":\"5\",\"name\":\"Bab\",\"created_at\":null,\"updated_at\":null},{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"4\",\"name\":\"Csirke\",\"created_at\":null,\"updated_at\":null}]', 'Normál', 2200, 1, 2200, '2021-12-30 16:44:18', NULL),
(0, 2, 15, 'Mexicoi', '[{\"id\":\"5\",\"name\":\"Bab\",\"created_at\":null,\"updated_at\":null},{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"4\",\"name\":\"Csirke\",\"created_at\":null,\"updated_at\":null}]', 'Normál', 2200, 1, 2200, '2021-12-30 16:44:25', NULL),
(0, 2, 16, 'Mexicoi', '[{\"id\":\"5\",\"name\":\"Bab\",\"created_at\":null,\"updated_at\":null},{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"4\",\"name\":\"Csirke\",\"created_at\":null,\"updated_at\":null}]', 'Normál', 2200, 1, 2200, '2021-12-30 16:44:26', NULL),
(0, 2, 17, 'Mexicoi', '[{\"id\":\"5\",\"name\":\"Bab\",\"created_at\":null,\"updated_at\":null},{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"4\",\"name\":\"Csirke\",\"created_at\":null,\"updated_at\":null}]', 'Normál', 2200, 1, 2200, '2021-12-30 16:44:26', NULL),
(0, 2, 18, 'Mexicoi', '[{\"id\":\"5\",\"name\":\"Bab\",\"created_at\":null,\"updated_at\":null},{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"4\",\"name\":\"Csirke\",\"created_at\":null,\"updated_at\":null}]', 'Normál', 2200, 1, 2200, '2021-12-30 16:44:27', NULL),
(0, 2, 19, 'Mexicoi', '[{\"id\":\"5\",\"name\":\"Bab\",\"created_at\":null,\"updated_at\":null},{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"4\",\"name\":\"Csirke\",\"created_at\":null,\"updated_at\":null}]', 'Normál', 2200, 1, 2200, '2021-12-30 16:44:27', NULL),
(0, 2, 20, 'Mexicoi', '[{\"id\":\"5\",\"name\":\"Bab\",\"created_at\":null,\"updated_at\":null},{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"4\",\"name\":\"Csirke\",\"created_at\":null,\"updated_at\":null}]', 'Normál', 2200, 1, 2200, '2021-12-30 16:44:29', NULL),
(0, 4, 21, 'Magyaros', '[{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"9\",\"name\":\"Kolbu00e1sz\",\"created_at\":null,\"updated_at\":null},{\"id\":\"7\",\"name\":\"Bacon\",\"created_at\":null,\"updated_at\":null},{\"id\":\"8\",\"name\":\"Paradicsom\",\"created_at\":null,\"updated_at\":null},{\"id\":\"10\",\"name\":\"Csemegeuborka\",\"created_at\":null,\"updated_at\":null}]', 'Nagy', 4300, 1, 4300, '2021-12-30 16:49:13', NULL),
(0, 4, 22, 'Magyaros', '[{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"9\",\"name\":\"Kolbu00e1sz\",\"created_at\":null,\"updated_at\":null},{\"id\":\"7\",\"name\":\"Bacon\",\"created_at\":null,\"updated_at\":null},{\"id\":\"8\",\"name\":\"Paradicsom\",\"created_at\":null,\"updated_at\":null},{\"id\":\"10\",\"name\":\"Csemegeuborka\",\"created_at\":null,\"updated_at\":null}]', 'Nagy', 4300, 1, 4300, '2021-12-30 16:49:14', NULL),
(0, 4, 23, 'Magyaros', '[{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"9\",\"name\":\"Kolbu00e1sz\",\"created_at\":null,\"updated_at\":null},{\"id\":\"7\",\"name\":\"Bacon\",\"created_at\":null,\"updated_at\":null},{\"id\":\"8\",\"name\":\"Paradicsom\",\"created_at\":null,\"updated_at\":null},{\"id\":\"10\",\"name\":\"Csemegeuborka\",\"created_at\":null,\"updated_at\":null}]', 'Nagy', 4300, 1, 4300, '2021-12-30 16:49:29', NULL),
(0, 4, 24, 'Magyaros', '[{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"9\",\"name\":\"Kolbu00e1sz\",\"created_at\":null,\"updated_at\":null},{\"id\":\"7\",\"name\":\"Bacon\",\"created_at\":null,\"updated_at\":null},{\"id\":\"8\",\"name\":\"Paradicsom\",\"created_at\":null,\"updated_at\":null},{\"id\":\"10\",\"name\":\"Csemegeuborka\",\"created_at\":null,\"updated_at\":null}]', 'Nagy', 4300, 1, 4300, '2021-12-30 16:50:55', NULL),
(0, 4, 25, 'Magyaros', '[{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"9\",\"name\":\"Kolbu00e1sz\",\"created_at\":null,\"updated_at\":null},{\"id\":\"7\",\"name\":\"Bacon\",\"created_at\":null,\"updated_at\":null},{\"id\":\"8\",\"name\":\"Paradicsom\",\"created_at\":null,\"updated_at\":null},{\"id\":\"10\",\"name\":\"Csemegeuborka\",\"created_at\":null,\"updated_at\":null}]', 'Nagy', 4300, 1, 4300, '2021-12-30 16:51:44', NULL),
(0, 4, 26, 'Magyaros', '[{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"9\",\"name\":\"Kolbu00e1sz\",\"created_at\":null,\"updated_at\":null},{\"id\":\"7\",\"name\":\"Bacon\",\"created_at\":null,\"updated_at\":null},{\"id\":\"8\",\"name\":\"Paradicsom\",\"created_at\":null,\"updated_at\":null},{\"id\":\"10\",\"name\":\"Csemegeuborka\",\"created_at\":null,\"updated_at\":null}]', 'Nagy', 4300, 1, 4300, '2021-12-30 16:52:47', NULL),
(0, 4, 27, 'Magyaros', '[{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"9\",\"name\":\"Kolbu00e1sz\",\"created_at\":null,\"updated_at\":null},{\"id\":\"7\",\"name\":\"Bacon\",\"created_at\":null,\"updated_at\":null},{\"id\":\"8\",\"name\":\"Paradicsom\",\"created_at\":null,\"updated_at\":null},{\"id\":\"10\",\"name\":\"Csemegeuborka\",\"created_at\":null,\"updated_at\":null}]', 'Nagy', 4300, 1, 4300, '2021-12-30 16:53:09', NULL),
(0, 4, 28, 'Magyaros', '[{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"9\",\"name\":\"Kolbu00e1sz\",\"created_at\":null,\"updated_at\":null},{\"id\":\"7\",\"name\":\"Bacon\",\"created_at\":null,\"updated_at\":null},{\"id\":\"8\",\"name\":\"Paradicsom\",\"created_at\":null,\"updated_at\":null},{\"id\":\"10\",\"name\":\"Csemegeuborka\",\"created_at\":null,\"updated_at\":null}]', 'Nagy', 4300, 1, 4300, '2021-12-30 16:57:11', NULL),
(0, 4, 29, 'Magyaros', '[{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"9\",\"name\":\"Kolbu00e1sz\",\"created_at\":null,\"updated_at\":null},{\"id\":\"7\",\"name\":\"Bacon\",\"created_at\":null,\"updated_at\":null},{\"id\":\"8\",\"name\":\"Paradicsom\",\"created_at\":null,\"updated_at\":null},{\"id\":\"10\",\"name\":\"Csemegeuborka\",\"created_at\":null,\"updated_at\":null}]', 'Normál', 2500, 1, 2500, '2022-07-20 10:19:39', NULL),
(0, 4, 30, 'Magyaros', '[{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"9\",\"name\":\"Kolbu00e1sz\",\"created_at\":null,\"updated_at\":null},{\"id\":\"7\",\"name\":\"Bacon\",\"created_at\":null,\"updated_at\":null},{\"id\":\"8\",\"name\":\"Paradicsom\",\"created_at\":null,\"updated_at\":null},{\"id\":\"10\",\"name\":\"Csemegeuborka\",\"created_at\":null,\"updated_at\":null}]', 'Normál', 2500, 1, 2500, '2022-07-20 10:19:43', NULL),
(0, 4, 31, 'Magyaros', '[{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"9\",\"name\":\"Kolbu00e1sz\",\"created_at\":null,\"updated_at\":null},{\"id\":\"7\",\"name\":\"Bacon\",\"created_at\":null,\"updated_at\":null},{\"id\":\"8\",\"name\":\"Paradicsom\",\"created_at\":null,\"updated_at\":null},{\"id\":\"10\",\"name\":\"Csemegeuborka\",\"created_at\":null,\"updated_at\":null}]', 'Normál', 2500, 1, 2500, '2022-07-20 10:19:50', NULL),
(0, 4, 32, 'Magyaros', '[{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"9\",\"name\":\"Kolbu00e1sz\",\"created_at\":null,\"updated_at\":null},{\"id\":\"7\",\"name\":\"Bacon\",\"created_at\":null,\"updated_at\":null},{\"id\":\"8\",\"name\":\"Paradicsom\",\"created_at\":null,\"updated_at\":null},{\"id\":\"10\",\"name\":\"Csemegeuborka\",\"created_at\":null,\"updated_at\":null}]', 'Normál', 2500, 1, 2500, '2022-07-20 10:20:11', NULL),
(0, 4, 33, 'Magyaros', '[{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"9\",\"name\":\"Kolbu00e1sz\",\"created_at\":null,\"updated_at\":null},{\"id\":\"7\",\"name\":\"Bacon\",\"created_at\":null,\"updated_at\":null},{\"id\":\"8\",\"name\":\"Paradicsom\",\"created_at\":null,\"updated_at\":null},{\"id\":\"10\",\"name\":\"Csemegeuborka\",\"created_at\":null,\"updated_at\":null}]', 'Normál', 2500, 1, 2500, '2022-07-20 10:20:12', NULL),
(0, 4, 34, 'Magyaros', '[{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"9\",\"name\":\"Kolbu00e1sz\",\"created_at\":null,\"updated_at\":null},{\"id\":\"7\",\"name\":\"Bacon\",\"created_at\":null,\"updated_at\":null},{\"id\":\"8\",\"name\":\"Paradicsom\",\"created_at\":null,\"updated_at\":null},{\"id\":\"10\",\"name\":\"Csemegeuborka\",\"created_at\":null,\"updated_at\":null}]', 'Normál', 2500, 1, 2500, '2022-07-20 10:20:12', NULL),
(0, 4, 35, 'Magyaros', '[{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"9\",\"name\":\"Kolbu00e1sz\",\"created_at\":null,\"updated_at\":null},{\"id\":\"7\",\"name\":\"Bacon\",\"created_at\":null,\"updated_at\":null},{\"id\":\"8\",\"name\":\"Paradicsom\",\"created_at\":null,\"updated_at\":null},{\"id\":\"10\",\"name\":\"Csemegeuborka\",\"created_at\":null,\"updated_at\":null}]', 'Normál', 2500, 1, 2500, '2022-07-20 10:20:12', NULL),
(0, 4, 36, 'Magyaros', '[{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"9\",\"name\":\"Kolbu00e1sz\",\"created_at\":null,\"updated_at\":null},{\"id\":\"7\",\"name\":\"Bacon\",\"created_at\":null,\"updated_at\":null},{\"id\":\"8\",\"name\":\"Paradicsom\",\"created_at\":null,\"updated_at\":null},{\"id\":\"10\",\"name\":\"Csemegeuborka\",\"created_at\":null,\"updated_at\":null}]', 'Normál', 2500, 1, 2500, '2022-07-20 10:20:28', NULL),
(0, 4, 37, 'Magyaros', '[{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"9\",\"name\":\"Kolbu00e1sz\",\"created_at\":null,\"updated_at\":null},{\"id\":\"7\",\"name\":\"Bacon\",\"created_at\":null,\"updated_at\":null},{\"id\":\"8\",\"name\":\"Paradicsom\",\"created_at\":null,\"updated_at\":null},{\"id\":\"10\",\"name\":\"Csemegeuborka\",\"created_at\":null,\"updated_at\":null}]', 'Normál', 2500, 1, 2500, '2022-07-20 10:20:28', NULL),
(0, 4, 38, 'Magyaros', '[{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"9\",\"name\":\"Kolbu00e1sz\",\"created_at\":null,\"updated_at\":null},{\"id\":\"7\",\"name\":\"Bacon\",\"created_at\":null,\"updated_at\":null},{\"id\":\"8\",\"name\":\"Paradicsom\",\"created_at\":null,\"updated_at\":null},{\"id\":\"10\",\"name\":\"Csemegeuborka\",\"created_at\":null,\"updated_at\":null}]', 'Normál', 2500, 1, 2500, '2022-07-20 10:20:29', NULL),
(0, 4, 39, 'Magyaros', '[{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"9\",\"name\":\"Kolbu00e1sz\",\"created_at\":null,\"updated_at\":null},{\"id\":\"7\",\"name\":\"Bacon\",\"created_at\":null,\"updated_at\":null},{\"id\":\"8\",\"name\":\"Paradicsom\",\"created_at\":null,\"updated_at\":null},{\"id\":\"10\",\"name\":\"Csemegeuborka\",\"created_at\":null,\"updated_at\":null}]', 'Normál', 2500, 1, 2500, '2022-07-20 10:20:29', NULL),
(0, 4, 40, 'Magyaros', '[{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"9\",\"name\":\"Kolbu00e1sz\",\"created_at\":null,\"updated_at\":null},{\"id\":\"7\",\"name\":\"Bacon\",\"created_at\":null,\"updated_at\":null},{\"id\":\"8\",\"name\":\"Paradicsom\",\"created_at\":null,\"updated_at\":null},{\"id\":\"10\",\"name\":\"Csemegeuborka\",\"created_at\":null,\"updated_at\":null}]', 'Normál', 2500, 1, 2500, '2022-07-20 10:20:29', NULL),
(0, 4, 41, 'Magyaros', '[{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"9\",\"name\":\"Kolbu00e1sz\",\"created_at\":null,\"updated_at\":null},{\"id\":\"7\",\"name\":\"Bacon\",\"created_at\":null,\"updated_at\":null},{\"id\":\"8\",\"name\":\"Paradicsom\",\"created_at\":null,\"updated_at\":null},{\"id\":\"10\",\"name\":\"Csemegeuborka\",\"created_at\":null,\"updated_at\":null}]', 'Normál', 2500, 1, 2500, '2022-07-20 10:20:29', NULL),
(0, 4, 42, 'Magyaros', '[{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"9\",\"name\":\"Kolbu00e1sz\",\"created_at\":null,\"updated_at\":null},{\"id\":\"7\",\"name\":\"Bacon\",\"created_at\":null,\"updated_at\":null},{\"id\":\"8\",\"name\":\"Paradicsom\",\"created_at\":null,\"updated_at\":null},{\"id\":\"10\",\"name\":\"Csemegeuborka\",\"created_at\":null,\"updated_at\":null}]', 'Normál', 2500, 1, 2500, '2022-07-20 10:20:30', NULL),
(0, 4, 43, 'Magyaros', '[{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"9\",\"name\":\"Kolbu00e1sz\",\"created_at\":null,\"updated_at\":null},{\"id\":\"7\",\"name\":\"Bacon\",\"created_at\":null,\"updated_at\":null},{\"id\":\"8\",\"name\":\"Paradicsom\",\"created_at\":null,\"updated_at\":null},{\"id\":\"10\",\"name\":\"Csemegeuborka\",\"created_at\":null,\"updated_at\":null}]', 'Normál', 2500, 1, 2500, '2022-07-20 10:20:30', NULL),
(0, 4, 44, 'Magyaros', '[{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"9\",\"name\":\"Kolbu00e1sz\",\"created_at\":null,\"updated_at\":null},{\"id\":\"7\",\"name\":\"Bacon\",\"created_at\":null,\"updated_at\":null},{\"id\":\"8\",\"name\":\"Paradicsom\",\"created_at\":null,\"updated_at\":null},{\"id\":\"10\",\"name\":\"Csemegeuborka\",\"created_at\":null,\"updated_at\":null}]', 'Normál', 2500, 1, 2500, '2022-07-20 10:20:31', NULL),
(0, 4, 45, 'Magyaros', '[{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"9\",\"name\":\"Kolbu00e1sz\",\"created_at\":null,\"updated_at\":null},{\"id\":\"7\",\"name\":\"Bacon\",\"created_at\":null,\"updated_at\":null},{\"id\":\"8\",\"name\":\"Paradicsom\",\"created_at\":null,\"updated_at\":null},{\"id\":\"10\",\"name\":\"Csemegeuborka\",\"created_at\":null,\"updated_at\":null}]', 'Normál', 2500, 1, 2500, '2022-07-20 10:20:43', NULL),
(0, 4, 46, 'Magyaros', '[{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"9\",\"name\":\"Kolbu00e1sz\",\"created_at\":null,\"updated_at\":null},{\"id\":\"7\",\"name\":\"Bacon\",\"created_at\":null,\"updated_at\":null},{\"id\":\"8\",\"name\":\"Paradicsom\",\"created_at\":null,\"updated_at\":null},{\"id\":\"10\",\"name\":\"Csemegeuborka\",\"created_at\":null,\"updated_at\":null}]', 'Normál', 2500, 1, 2500, '2022-07-20 10:20:43', NULL),
(0, 4, 47, 'Magyaros', '[{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"9\",\"name\":\"Kolbu00e1sz\",\"created_at\":null,\"updated_at\":null},{\"id\":\"7\",\"name\":\"Bacon\",\"created_at\":null,\"updated_at\":null},{\"id\":\"8\",\"name\":\"Paradicsom\",\"created_at\":null,\"updated_at\":null},{\"id\":\"10\",\"name\":\"Csemegeuborka\",\"created_at\":null,\"updated_at\":null}]', 'Normál', 2500, 1, 2500, '2022-07-20 10:20:44', NULL),
(0, 4, 48, 'Magyaros', '[{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"9\",\"name\":\"Kolbu00e1sz\",\"created_at\":null,\"updated_at\":null},{\"id\":\"7\",\"name\":\"Bacon\",\"created_at\":null,\"updated_at\":null},{\"id\":\"8\",\"name\":\"Paradicsom\",\"created_at\":null,\"updated_at\":null},{\"id\":\"10\",\"name\":\"Csemegeuborka\",\"created_at\":null,\"updated_at\":null}]', 'Normál', 2500, 1, 2500, '2022-07-20 10:22:49', NULL),
(0, 4, 49, 'Magyaros', '[{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"9\",\"name\":\"Kolbu00e1sz\",\"created_at\":null,\"updated_at\":null},{\"id\":\"7\",\"name\":\"Bacon\",\"created_at\":null,\"updated_at\":null},{\"id\":\"8\",\"name\":\"Paradicsom\",\"created_at\":null,\"updated_at\":null},{\"id\":\"10\",\"name\":\"Csemegeuborka\",\"created_at\":null,\"updated_at\":null}]', 'Normál', 2500, 1, 2500, '2022-07-20 10:22:50', NULL),
(0, 4, 50, 'Magyaros', '[{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"9\",\"name\":\"Kolbu00e1sz\",\"created_at\":null,\"updated_at\":null},{\"id\":\"7\",\"name\":\"Bacon\",\"created_at\":null,\"updated_at\":null},{\"id\":\"8\",\"name\":\"Paradicsom\",\"created_at\":null,\"updated_at\":null},{\"id\":\"10\",\"name\":\"Csemegeuborka\",\"created_at\":null,\"updated_at\":null}]', 'Normál', 2500, 1, 2500, '2022-07-20 10:22:50', NULL),
(0, 4, 51, 'Magyaros', '[{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"9\",\"name\":\"Kolbu00e1sz\",\"created_at\":null,\"updated_at\":null},{\"id\":\"7\",\"name\":\"Bacon\",\"created_at\":null,\"updated_at\":null},{\"id\":\"8\",\"name\":\"Paradicsom\",\"created_at\":null,\"updated_at\":null},{\"id\":\"10\",\"name\":\"Csemegeuborka\",\"created_at\":null,\"updated_at\":null}]', 'Normál', 2500, 1, 2500, '2022-07-20 10:22:52', NULL),
(0, 4, 52, 'Magyaros', '[{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"9\",\"name\":\"Kolbu00e1sz\",\"created_at\":null,\"updated_at\":null},{\"id\":\"7\",\"name\":\"Bacon\",\"created_at\":null,\"updated_at\":null},{\"id\":\"8\",\"name\":\"Paradicsom\",\"created_at\":null,\"updated_at\":null},{\"id\":\"10\",\"name\":\"Csemegeuborka\",\"created_at\":null,\"updated_at\":null}]', 'Normál', 2500, 1, 2500, '2022-07-20 10:22:52', NULL),
(0, 4, 53, 'Magyaros', '[{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"9\",\"name\":\"Kolbu00e1sz\",\"created_at\":null,\"updated_at\":null},{\"id\":\"7\",\"name\":\"Bacon\",\"created_at\":null,\"updated_at\":null},{\"id\":\"8\",\"name\":\"Paradicsom\",\"created_at\":null,\"updated_at\":null},{\"id\":\"10\",\"name\":\"Csemegeuborka\",\"created_at\":null,\"updated_at\":null}]', 'Normál', 2500, 1, 2500, '2022-07-20 10:22:53', NULL),
(0, 4, 54, 'Magyaros', '[{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"9\",\"name\":\"Kolbu00e1sz\",\"created_at\":null,\"updated_at\":null},{\"id\":\"7\",\"name\":\"Bacon\",\"created_at\":null,\"updated_at\":null},{\"id\":\"8\",\"name\":\"Paradicsom\",\"created_at\":null,\"updated_at\":null},{\"id\":\"10\",\"name\":\"Csemegeuborka\",\"created_at\":null,\"updated_at\":null}]', 'Normál', 2500, 1, 2500, '2022-07-20 10:22:53', NULL),
(0, 4, 55, 'Magyaros', '[{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"9\",\"name\":\"Kolbu00e1sz\",\"created_at\":null,\"updated_at\":null},{\"id\":\"7\",\"name\":\"Bacon\",\"created_at\":null,\"updated_at\":null},{\"id\":\"8\",\"name\":\"Paradicsom\",\"created_at\":null,\"updated_at\":null},{\"id\":\"10\",\"name\":\"Csemegeuborka\",\"created_at\":null,\"updated_at\":null}]', 'Normál', 2500, 1, 2500, '2022-07-20 10:23:16', NULL),
(0, 4, 56, 'Magyaros', '[{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"9\",\"name\":\"Kolbu00e1sz\",\"created_at\":null,\"updated_at\":null},{\"id\":\"7\",\"name\":\"Bacon\",\"created_at\":null,\"updated_at\":null},{\"id\":\"8\",\"name\":\"Paradicsom\",\"created_at\":null,\"updated_at\":null},{\"id\":\"10\",\"name\":\"Csemegeuborka\",\"created_at\":null,\"updated_at\":null}]', 'Normál', 2500, 1, 2500, '2022-07-20 10:23:22', NULL),
(0, 4, 57, 'Magyaros', '[{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"9\",\"name\":\"Kolbu00e1sz\",\"created_at\":null,\"updated_at\":null},{\"id\":\"7\",\"name\":\"Bacon\",\"created_at\":null,\"updated_at\":null},{\"id\":\"8\",\"name\":\"Paradicsom\",\"created_at\":null,\"updated_at\":null},{\"id\":\"10\",\"name\":\"Csemegeuborka\",\"created_at\":null,\"updated_at\":null}]', 'Normál', 2500, 1, 2500, '2022-07-20 10:23:29', NULL),
(0, 4, 58, 'Magyaros', '[{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"9\",\"name\":\"Kolbu00e1sz\",\"created_at\":null,\"updated_at\":null},{\"id\":\"7\",\"name\":\"Bacon\",\"created_at\":null,\"updated_at\":null},{\"id\":\"8\",\"name\":\"Paradicsom\",\"created_at\":null,\"updated_at\":null},{\"id\":\"10\",\"name\":\"Csemegeuborka\",\"created_at\":null,\"updated_at\":null}]', 'Normál', 2500, 1, 2500, '2022-07-20 10:23:29', NULL),
(0, 4, 59, 'Magyaros', '[{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"9\",\"name\":\"Kolbu00e1sz\",\"created_at\":null,\"updated_at\":null},{\"id\":\"7\",\"name\":\"Bacon\",\"created_at\":null,\"updated_at\":null},{\"id\":\"8\",\"name\":\"Paradicsom\",\"created_at\":null,\"updated_at\":null},{\"id\":\"10\",\"name\":\"Csemegeuborka\",\"created_at\":null,\"updated_at\":null}]', 'Normál', 2500, 1, 2500, '2022-07-20 10:23:30', NULL),
(0, 4, 60, 'Magyaros', '[{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"9\",\"name\":\"Kolbu00e1sz\",\"created_at\":null,\"updated_at\":null},{\"id\":\"7\",\"name\":\"Bacon\",\"created_at\":null,\"updated_at\":null},{\"id\":\"8\",\"name\":\"Paradicsom\",\"created_at\":null,\"updated_at\":null},{\"id\":\"10\",\"name\":\"Csemegeuborka\",\"created_at\":null,\"updated_at\":null}]', 'Normál', 2500, 1, 2500, '2022-07-20 10:31:15', NULL),
(0, 4, 61, 'Magyaros', '[{\"id\":\"1\",\"name\":\"Sajt\",\"created_at\":null,\"updated_at\":null},{\"id\":\"9\",\"name\":\"Kolbu00e1sz\",\"created_at\":null,\"updated_at\":null},{\"id\":\"7\",\"name\":\"Bacon\",\"created_at\":null,\"updated_at\":null},{\"id\":\"8\",\"name\":\"Paradicsom\",\"created_at\":null,\"updated_at\":null},{\"id\":\"10\",\"name\":\"Csemegeuborka\",\"created_at\":null,\"updated_at\":null}]', 'Normál', 2500, 1, 2500, '2022-07-20 10:31:16', NULL);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `pizzas`
--

CREATE TABLE `pizzas` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `url` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `hot_deal` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- A tábla adatainak kiíratása `pizzas`
--

INSERT INTO `pizzas` (`id`, `url`, `name`, `image`, `description`, `hot_deal`, `created_at`, `updated_at`) VALUES
(1, 'suprame', 'Suprame', '1.jpg', '', 1, NULL, NULL),
(2, 'mexicoi', 'Mexicoi', '2.jpg', '', 1, NULL, NULL),
(3, 'songoku', 'Songoku', '3.jpg', '', 1, NULL, NULL),
(4, 'magyaros', 'Magyaros', '5.jpg', '', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `pizzas_sizes`
--

CREATE TABLE `pizzas_sizes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `pizza_id` bigint(20) UNSIGNED NOT NULL,
  `size_id` bigint(20) UNSIGNED NOT NULL,
  `price` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- A tábla adatainak kiíratása `pizzas_sizes`
--

INSERT INTO `pizzas_sizes` (`id`, `pizza_id`, `size_id`, `price`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 2300, NULL, NULL),
(2, 1, 2, 4100, NULL, NULL),
(3, 2, 1, 2200, NULL, NULL),
(4, 2, 2, 3900, NULL, NULL),
(5, 3, 1, 2600, NULL, NULL),
(6, 3, 2, 4500, NULL, NULL),
(7, 4, 1, 2500, NULL, NULL),
(8, 4, 2, 4300, NULL, NULL);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `pizzas_toppings`
--

CREATE TABLE `pizzas_toppings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `pizza_id` bigint(20) UNSIGNED NOT NULL,
  `topping_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- A tábla adatainak kiíratása `pizzas_toppings`
--

INSERT INTO `pizzas_toppings` (`id`, `pizza_id`, `topping_id`, `created_at`, `updated_at`) VALUES
(1, 1, 3, NULL, NULL),
(2, 1, 1, NULL, NULL),
(3, 2, 5, NULL, NULL),
(4, 2, 1, NULL, NULL),
(5, 2, 4, NULL, NULL),
(6, 3, 2, NULL, NULL),
(7, 3, 6, NULL, NULL),
(8, 3, 1, NULL, NULL),
(9, 3, 11, NULL, NULL),
(10, 4, 1, NULL, NULL),
(11, 4, 9, NULL, NULL),
(12, 4, 7, NULL, NULL),
(13, 4, 8, NULL, NULL),
(14, 4, 10, NULL, NULL);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `sizes`
--

CREATE TABLE `sizes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `default` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- A tábla adatainak kiíratása `sizes`
--

INSERT INTO `sizes` (`id`, `name`, `default`, `created_at`, `updated_at`) VALUES
(1, 'Normál', 1, NULL, NULL),
(2, 'Nagy', 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `toppings`
--

CREATE TABLE `toppings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- A tábla adatainak kiíratása `toppings`
--

INSERT INTO `toppings` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Sajt', NULL, NULL),
(2, 'Sonka', NULL, NULL),
(3, 'Szalámi', NULL, NULL),
(4, 'Csirke', NULL, NULL),
(5, 'Bab', NULL, NULL),
(6, 'Gomba', NULL, NULL),
(7, 'Bacon', NULL, NULL),
(8, 'Paradicsom', NULL, NULL),
(9, 'Kolbász', NULL, NULL),
(10, 'Csemegeuborka', NULL, NULL),
(11, 'Kukorica', NULL, NULL);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `type` enum('user','guest') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'guest',
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `new_email` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_zip` int(11) NOT NULL,
  `shipping_city` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shipping_street` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shipping_nr` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billing_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billing_tax_nr` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billing_zip` int(11) NOT NULL,
  `billing_nr` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billing_street` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `billing_city` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `verification_token` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- A tábla adatainak kiíratása `users`
--

INSERT INTO `users` (`id`, `type`, `first_name`, `last_name`, `email`, `new_email`, `email_verified_at`, `password`, `shipping_zip`, `shipping_city`, `shipping_street`, `shipping_nr`, `billing_name`, `billing_tax_nr`, `billing_zip`, `billing_nr`, `billing_street`, `billing_city`, `remember_token`, `verification_token`, `created_at`, `updated_at`) VALUES
(6, 'guest', 'Farkas', 'Bence', 'farkasbence@gmail.com', NULL, NULL, NULL, 1028, 'Budapest, II.', 'Máriaremetei Út 11', '', 'Farkas Bence', '', 1028, '', 'Máriaremetei Út 11', 'Budapest, II.', NULL, NULL, '2021-12-03 17:34:24', NULL),
(8, 'user', 'Farkas', 'Bence', 'farkasbence2@gmail.com', NULL, '2021-12-18 09:32:27', 'c334246cfc6455f1e084c7646a04f432', 0, '', '', NULL, NULL, NULL, 0, NULL, '', '', NULL, '72ef8d172133c6547c483dafa33f7b51fa147d938d9807ef9ea4c1f74d494cef3714482', '2021-12-18 09:32:13', '2021-12-18 09:32:27'),
(9, 'guest', 'Farkas', 'Bence', 'farkasbence@gmail.com', NULL, NULL, NULL, 1028, 'Budapest, II.', 'Máriaremetei Út 11', '', 'Farkas Bence', '', 1028, '', 'Máriaremetei Út 11', 'Budapest, II.', NULL, NULL, '2021-12-21 17:19:20', '2021-12-21 17:19:20'),
(10, 'guest', 'Farkas', 'Bence', 'ducati.96@hotmail.com', NULL, NULL, NULL, 1028, 'Budapest, II.', 'Máriaremetei Út 11', '', 'Farkas Bence', '', 1028, '', 'Máriaremetei Út 11', 'Budapest, II.', NULL, NULL, '2021-12-21 17:20:43', '2021-12-21 17:20:43'),
(11, 'guest', 'Farkas', 'Bence', 'farkasbence2@gmail.com', NULL, NULL, NULL, 1028, 'Budapest, II.', 'Máriaremetei Út 11', '', 'Farkas Bence', '', 1028, '', 'Máriaremetei Út 11', 'Budapest, II.', NULL, NULL, '2021-12-30 16:43:35', '2021-12-30 16:43:35'),
(12, 'guest', 'Farkas', 'Bence', 'farkasbence2@gmail.com', NULL, NULL, NULL, 1028, 'Budapest, II.', 'Máriaremetei Út 11', '', 'Farkas Bence', '', 1028, '', 'Máriaremetei Út 11', 'Budapest, II.', NULL, NULL, '2021-12-30 16:43:38', '2021-12-30 16:43:38'),
(13, 'guest', 'Farkas', 'Bence', 'farkasbence2@gmail.com', NULL, NULL, NULL, 1028, 'Budapest, II.', 'Máriaremetei Út 11', '1', 'Farkas Bence', '', 1028, '1', 'Máriaremetei Út 11', 'Budapest, II.', NULL, NULL, '2021-12-30 16:43:47', '2021-12-30 16:43:47'),
(14, 'guest', 'Farkas', 'Bence', 'farkasbence2@gmail.com', NULL, NULL, NULL, 1028, 'Budapest, II.', 'Máriaremetei Út 11', '1', 'Farkas Bence', '', 1028, '1', 'Máriaremetei Út 11', 'Budapest, II.', NULL, NULL, '2021-12-30 16:43:48', '2021-12-30 16:43:48'),
(15, 'guest', 'Farkas', 'Bence', 'farkasbence2@gmail.com', NULL, NULL, NULL, 1028, 'Budapest, II.', 'Máriaremetei Út 11', '1', 'Farkas Bence', '', 1028, '1', 'Máriaremetei Út 11', 'Budapest, II.', NULL, NULL, '2021-12-30 16:43:48', '2021-12-30 16:43:48'),
(16, 'guest', 'Farkas', 'Bence', 'farkasbence2@gmail.com', NULL, NULL, NULL, 1028, 'Budapest, II.', 'Máriaremetei Út 11', '1', 'Farkas Bence', '', 1028, '1', 'Máriaremetei Út 11', 'Budapest, II.', NULL, NULL, '2021-12-30 16:43:48', '2021-12-30 16:43:48'),
(17, 'guest', 'Farkas', 'Bence', 'farkasbence2@gmail.com', NULL, NULL, NULL, 1028, 'Budapest, II.', 'Máriaremetei Út 11', '1', 'Farkas Bence', '', 1028, '1', 'Máriaremetei Út 11', 'Budapest, II.', NULL, NULL, '2021-12-30 16:43:52', '2021-12-30 16:43:52'),
(18, 'guest', 'aaaa', 'aaaa', 'farkasbence2@gmail.com', NULL, NULL, NULL, 2222, 'Budapest', 'asdasd', '111', 'aaaa aaaa', '', 2222, '111', 'asdasd', 'Budapest', NULL, NULL, '2021-12-30 16:44:18', '2021-12-30 16:44:18'),
(19, 'guest', 'aaaa', 'aaaa', 'farkasbence2@gmail.com', NULL, NULL, NULL, 2222, 'Budapest', 'asdasd', '111', 'aaaa aaaa', '', 2222, '111', 'asdasd', 'Budapest', NULL, NULL, '2021-12-30 16:44:25', '2021-12-30 16:44:25'),
(20, 'guest', 'aaaa', 'aaaa', 'farkasbence2@gmail.com', NULL, NULL, NULL, 2222, 'Budapest', 'asdasd', '111', 'aaaa aaaa', '', 2222, '111', 'asdasd', 'Budapest', NULL, NULL, '2021-12-30 16:44:26', '2021-12-30 16:44:26'),
(21, 'guest', 'aaaa', 'aaaa', 'farkasbence2@gmail.com', NULL, NULL, NULL, 2222, 'Budapest', 'asdasd', '111', 'aaaa aaaa', '', 2222, '111', 'asdasd', 'Budapest', NULL, NULL, '2021-12-30 16:44:26', '2021-12-30 16:44:26'),
(22, 'guest', 'aaaa', 'aaaa', 'farkasbence2@gmail.com', NULL, NULL, NULL, 2222, 'Budapest', 'asdasd', '111', 'aaaa aaaa', '', 2222, '111', 'asdasd', 'Budapest', NULL, NULL, '2021-12-30 16:44:27', '2021-12-30 16:44:27'),
(23, 'guest', 'aaaa', 'aaaa', 'farkasbence2@gmail.com', NULL, NULL, NULL, 2222, 'Budapest', 'asdasd', '111', 'aaaa aaaa', '', 2222, '111', 'asdasd', 'Budapest', NULL, NULL, '2021-12-30 16:44:27', '2021-12-30 16:44:27'),
(24, 'guest', 'aaaa', 'aaaa', 'farkasbence2@gmail.com', NULL, NULL, NULL, 2222, 'Budapest', 'asdasd', '111', 'aaaa aaaa', '', 2222, '111', 'asdasd', 'Budapest', NULL, NULL, '2021-12-30 16:44:29', '2021-12-30 16:44:29'),
(25, 'guest', 'Farkas', 'Bence', 'farkasbence@gmail.com', NULL, NULL, NULL, 1028, 'Budapest, II.', 'Máriaremetei Út 11', '1', 'Farkas Bence', '', 1028, '1', 'Máriaremetei Út 11', 'Budapest, II.', NULL, NULL, '2021-12-30 16:49:13', '2021-12-30 16:49:13'),
(26, 'guest', 'Farkas', 'Bence', 'farkasbence@gmail.com', NULL, NULL, NULL, 1028, 'Budapest, II.', 'Máriaremetei Út 11', '1', 'Farkas Bence', '', 1028, '1', 'Máriaremetei Út 11', 'Budapest, II.', NULL, NULL, '2021-12-30 16:49:13', '2021-12-30 16:49:14'),
(27, 'guest', 'Farkas', 'Bence', 'farkasbence@gmail.com', NULL, NULL, NULL, 1028, 'Budapest, II.', 'Máriaremetei Út 11', '1', 'Farkas Bence', '', 1028, '1', 'Máriaremetei Út 11', 'Budapest, II.', NULL, NULL, '2021-12-30 16:49:29', '2021-12-30 16:49:29'),
(28, 'guest', 'Farkas', 'Bence', 'farkasbence@gmail.com', NULL, NULL, NULL, 1028, 'Budapest, II.', 'Máriaremetei Út 11', '2', 'Farkas Bence', '', 1028, '2', 'Máriaremetei Út 11', 'Budapest, II.', NULL, NULL, '2021-12-30 16:50:55', '2021-12-30 16:50:55'),
(29, 'guest', 'Farkas', 'Bence', 'farkasbence@gmail.com', NULL, NULL, NULL, 1028, 'Budapest, II.', 'Máriaremetei Út 11', '1', 'Farkas Bence', '', 1028, '1', 'Máriaremetei Út 11', 'Budapest, II.', NULL, NULL, '2021-12-30 16:51:44', '2021-12-30 16:51:44'),
(30, 'guest', 'dasdas', 'asdasd', 'farkasbence@gmail.com', NULL, NULL, NULL, 2323, 'asdasd', 'asdasdas', '1', 'dasdas asdasd', '', 2323, '11', 'asdasdas', 'asdasd', NULL, NULL, '2021-12-30 16:52:47', '2021-12-30 16:52:47'),
(31, 'guest', 'dasdas', 'asdasd', 'farkasbence@gmail.com', NULL, NULL, NULL, 2323, 'asdasd', 'asdasdas', '1', 'dasdas asdasd', '', 2323, '11', 'asdasdas', 'asdasd', NULL, NULL, '2021-12-30 16:53:09', '2021-12-30 16:53:09'),
(32, 'guest', 'dasdas', 'asdasd', 'farkasbence@gmail.com', NULL, NULL, NULL, 2323, 'asdasd', 'asdasdas', '', 'dasdas asdasd', '', 2323, '', 'asdasdas', 'asdasd', NULL, NULL, '2021-12-30 16:57:11', '2021-12-30 16:57:11'),
(33, 'user', 'Farkas', 'Bence', 'Farkasbence2@gmail.com', NULL, NULL, NULL, 1028, 'Budapest, II.', 'Máriaremetei Út 11', '', 'Farkas Bence', '', 1028, '11', 'Máriaremetei Út 11', 'Budapest, II.', NULL, NULL, '2022-07-20 10:19:39', '2022-07-20 10:19:39'),
(34, 'user', 'Farkas', 'Bence', 'Farkasbence2@gmail.com', NULL, NULL, NULL, 1028, 'Budapest, II.', 'Máriaremetei Út 11', '', 'Farkas Bence', '', 1028, '11', 'Máriaremetei Út 11', 'Budapest, II.', NULL, NULL, '2022-07-20 10:19:42', '2022-07-20 10:19:43'),
(35, 'user', 'Farkas', 'Bence', 'Farkasbence2@gmail.com', NULL, NULL, NULL, 1028, 'Budapest, II.', 'Máriaremetei Út 11', '11', 'Farkas Bence', '', 1028, '11', 'Máriaremetei Út 11', 'Budapest, II.', NULL, NULL, '2022-07-20 10:19:50', '2022-07-20 10:19:50'),
(36, 'user', 'Farkas', 'Bence', 'Farkasbence2@gmail.com', NULL, NULL, NULL, 1028, 'Budapest, II.', 'Máriaremetei Út 11', '11', 'Farkas Bence', '', 1028, '11', 'Máriaremetei Út 11', 'Budapest, II.', NULL, NULL, '2022-07-20 10:20:11', '2022-07-20 10:20:11'),
(37, 'user', 'Farkas', 'Bence', 'Farkasbence2@gmail.com', NULL, NULL, NULL, 1028, 'Budapest, II.', 'Máriaremetei Út 11', '11', 'Farkas Bence', '', 1028, '11', 'Máriaremetei Út 11', 'Budapest, II.', NULL, NULL, '2022-07-20 10:20:12', '2022-07-20 10:20:12'),
(38, 'user', 'Farkas', 'Bence', 'Farkasbence2@gmail.com', NULL, NULL, NULL, 1028, 'Budapest, II.', 'Máriaremetei Út 11', '11', 'Farkas Bence', '', 1028, '11', 'Máriaremetei Út 11', 'Budapest, II.', NULL, NULL, '2022-07-20 10:20:12', '2022-07-20 10:20:12'),
(39, 'user', 'Farkas', 'Bence', 'Farkasbence2@gmail.com', NULL, NULL, NULL, 1028, 'Budapest, II.', 'Máriaremetei Út 11', '11', 'Farkas Bence', '', 1028, '11', 'Máriaremetei Út 11', 'Budapest, II.', NULL, NULL, '2022-07-20 10:20:12', '2022-07-20 10:20:12'),
(40, 'user', 'Farkas', 'Bence', 'farkasbence@gmail.com', NULL, NULL, NULL, 1028, 'Budapest, II.', 'Máriaremetei Út 11', '11', 'Farkas Bence', '', 1028, '11', 'Máriaremetei Út 11', 'Budapest, II.', NULL, NULL, '2022-07-20 10:20:28', '2022-07-20 10:20:28'),
(41, 'user', 'Farkas', 'Bence', 'farkasbence@gmail.com', NULL, NULL, NULL, 1028, 'Budapest, II.', 'Máriaremetei Út 11', '11', 'Farkas Bence', '', 1028, '11', 'Máriaremetei Út 11', 'Budapest, II.', NULL, NULL, '2022-07-20 10:20:28', '2022-07-20 10:20:28'),
(42, 'user', 'Farkas', 'Bence', 'farkasbence@gmail.com', NULL, NULL, NULL, 1028, 'Budapest, II.', 'Máriaremetei Út 11', '11', 'Farkas Bence', '', 1028, '11', 'Máriaremetei Út 11', 'Budapest, II.', NULL, NULL, '2022-07-20 10:20:29', '2022-07-20 10:20:29'),
(43, 'user', 'Farkas', 'Bence', 'farkasbence@gmail.com', NULL, NULL, NULL, 1028, 'Budapest, II.', 'Máriaremetei Út 11', '11', 'Farkas Bence', '', 1028, '11', 'Máriaremetei Út 11', 'Budapest, II.', NULL, NULL, '2022-07-20 10:20:29', '2022-07-20 10:20:29'),
(44, 'user', 'Farkas', 'Bence', 'farkasbence@gmail.com', NULL, NULL, NULL, 1028, 'Budapest, II.', 'Máriaremetei Út 11', '11', 'Farkas Bence', '', 1028, '11', 'Máriaremetei Út 11', 'Budapest, II.', NULL, NULL, '2022-07-20 10:20:29', '2022-07-20 10:20:29'),
(45, 'user', 'Farkas', 'Bence', 'farkasbence@gmail.com', NULL, NULL, NULL, 1028, 'Budapest, II.', 'Máriaremetei Út 11', '11', 'Farkas Bence', '', 1028, '11', 'Máriaremetei Út 11', 'Budapest, II.', NULL, NULL, '2022-07-20 10:20:29', '2022-07-20 10:20:29'),
(46, 'user', 'Farkas', 'Bence', 'farkasbence@gmail.com', NULL, NULL, NULL, 1028, 'Budapest, II.', 'Máriaremetei Út 11', '11', 'Farkas Bence', '', 1028, '11', 'Máriaremetei Út 11', 'Budapest, II.', NULL, NULL, '2022-07-20 10:20:30', '2022-07-20 10:20:30'),
(47, 'user', 'Farkas', 'Bence', 'farkasbence@gmail.com', NULL, NULL, NULL, 1028, 'Budapest, II.', 'Máriaremetei Út 11', '11', 'Farkas Bence', '', 1028, '11', 'Máriaremetei Út 11', 'Budapest, II.', NULL, NULL, '2022-07-20 10:20:30', '2022-07-20 10:20:30'),
(48, 'user', 'Farkas', 'Bence', 'farkasbence@gmail.com', NULL, NULL, NULL, 1028, 'Budapest, II.', 'Máriaremetei Út 11', '11', 'Farkas Bence', '', 1028, '11', 'Máriaremetei Út 11', 'Budapest, II.', NULL, NULL, '2022-07-20 10:20:30', '2022-07-20 10:20:31'),
(49, 'user', 'Farkas', 'Bence', 'farkasbence@gmail.com', NULL, NULL, NULL, 1028, 'Budapest, II.', 'Máriaremetei Út 11', '11', 'Farkas Bence', '', 1028, '11', 'Máriaremetei Út 11', 'Budapest, II.', NULL, NULL, '2022-07-20 10:20:43', '2022-07-20 10:20:43'),
(50, 'user', 'Farkas', 'Bence', 'farkasbence@gmail.com', NULL, NULL, NULL, 1028, 'Budapest, II.', 'Máriaremetei Út 11', '11', 'Farkas Bence', '', 1028, '11', 'Máriaremetei Út 11', 'Budapest, II.', NULL, NULL, '2022-07-20 10:20:43', '2022-07-20 10:20:43'),
(51, 'user', 'Farkas', 'Bence', 'farkasbence@gmail.com', NULL, NULL, NULL, 1028, 'Budapest, II.', 'Máriaremetei Út 11', '11', 'Farkas Bence', '', 1028, '11', 'Máriaremetei Út 11', 'Budapest, II.', NULL, NULL, '2022-07-20 10:20:44', '2022-07-20 10:20:44'),
(52, 'user', 'Farkas', 'Bence', 'ducati.96@hotmail.com', NULL, NULL, NULL, 1028, 'Budapest, II.', 'Máriaremetei Út 11', '', 'Farkas Bence', '', 1028, '11', 'Máriaremetei Út 11', 'Budapest, II.', NULL, NULL, '2022-07-20 10:22:49', '2022-07-20 10:22:49'),
(53, 'user', 'Farkas', 'Bence', 'ducati.96@hotmail.com', NULL, NULL, NULL, 1028, 'Budapest, II.', 'Máriaremetei Út 11', '', 'Farkas Bence', '', 1028, '11', 'Máriaremetei Út 11', 'Budapest, II.', NULL, NULL, '2022-07-20 10:22:50', '2022-07-20 10:22:50'),
(54, 'user', 'Farkas', 'Bence', 'ducati.96@hotmail.com', NULL, NULL, NULL, 1028, 'Budapest, II.', 'Máriaremetei Út 11', '', 'Farkas Bence', '', 1028, '11', 'Máriaremetei Út 11', 'Budapest, II.', NULL, NULL, '2022-07-20 10:22:50', '2022-07-20 10:22:50'),
(55, 'user', 'Farkas', 'Bence', 'ducati.96@hotmail.com', NULL, NULL, NULL, 1028, 'Budapest, II.', 'Máriaremetei Út 11', '', 'Farkas Bence', '', 1028, '11', 'Máriaremetei Út 11', 'Budapest, II.', NULL, NULL, '2022-07-20 10:22:52', '2022-07-20 10:22:52'),
(56, 'user', 'Farkas', 'Bence', 'ducati.96@hotmail.com', NULL, NULL, NULL, 1028, 'Budapest, II.', 'Máriaremetei Út 11', '', 'Farkas Bence', '', 1028, '11', 'Máriaremetei Út 11', 'Budapest, II.', NULL, NULL, '2022-07-20 10:22:52', '2022-07-20 10:22:52'),
(57, 'user', 'Farkas', 'Bence', 'ducati.96@hotmail.com', NULL, NULL, NULL, 1028, 'Budapest, II.', 'Máriaremetei Út 11', '', 'Farkas Bence', '', 1028, '11', 'Máriaremetei Út 11', 'Budapest, II.', NULL, NULL, '2022-07-20 10:22:53', '2022-07-20 10:22:53'),
(58, 'user', 'Farkas', 'Bence', 'ducati.96@hotmail.com', NULL, NULL, NULL, 1028, 'Budapest, II.', 'Máriaremetei Út 11', '', 'Farkas Bence', '', 1028, '11', 'Máriaremetei Út 11', 'Budapest, II.', NULL, NULL, '2022-07-20 10:22:53', '2022-07-20 10:22:53'),
(59, 'user', 'Farkas', 'Bence', 'farkasbence@gmail.com', NULL, NULL, NULL, 1028, 'Budapest, II.', 'Máriaremetei Út 11', '', 'Farkas Bence', '', 1028, '', 'Máriaremetei Út 11', 'Budapest, II.', NULL, NULL, '2022-07-20 10:23:16', '2022-07-20 10:23:16'),
(60, 'user', 'Farkas', 'Bence', 'farkasbence@gmail.com', NULL, NULL, NULL, 1028, 'Budapest, II.', 'Máriaremetei Út 11', '', 'Farkas Bence', '', 1028, '', 'Máriaremetei Út 11', 'Budapest, II.', NULL, NULL, '2022-07-20 10:23:22', '2022-07-20 10:23:22'),
(61, 'user', 'Farkas', 'Bence', 'farkasbence@gmail.com', NULL, NULL, NULL, 1028, 'Budapest, II.', 'Máriaremetei Út 11', '11', 'Farkas Bence', '', 1028, '11', 'Máriaremetei Út 11', 'Budapest, II.', NULL, NULL, '2022-07-20 10:23:29', '2022-07-20 10:23:29'),
(62, 'user', 'Farkas', 'Bence', 'farkasbence@gmail.com', NULL, NULL, NULL, 1028, 'Budapest, II.', 'Máriaremetei Út 11', '11', 'Farkas Bence', '', 1028, '11', 'Máriaremetei Út 11', 'Budapest, II.', NULL, NULL, '2022-07-20 10:23:29', '2022-07-20 10:23:29'),
(63, 'user', 'Farkas', 'Bence', 'farkasbence@gmail.com', NULL, NULL, NULL, 1028, 'Budapest, II.', 'Máriaremetei Út 11', '11', 'Farkas Bence', '', 1028, '11', 'Máriaremetei Út 11', 'Budapest, II.', NULL, NULL, '2022-07-20 10:23:29', '2022-07-20 10:23:30'),
(64, 'user', 'Farkas', 'Bence', 'tesztfarkasbence@gmail.com', NULL, NULL, 'c334246cfc6455f1e084c7646a04f432', 0, '', '', NULL, NULL, NULL, 0, NULL, '', '', NULL, '6c98e116d2c000c4b74f21ae7b6a09b8754a335a0259d7d21a48571be22656556390003', '2022-07-20 10:25:28', NULL),
(65, 'guest', 'Farkas', 'Bence', 'farkasbence2@gmail.coms', NULL, NULL, NULL, 1028, 'Budapest, II.', 'Máriaremetei Út 11', '11', 'Farkas Bence', '', 1028, '11', 'Máriaremetei Út 11', 'Budapest, II.', NULL, NULL, '2022-07-20 10:31:15', '2022-07-20 10:31:15'),
(66, 'guest', 'Farkas', 'Bence', 'farkasbence2@gmail.coms', NULL, NULL, NULL, 1028, 'Budapest, II.', 'Máriaremetei Út 11', '11', 'Farkas Bence', '', 1028, '11', 'Máriaremetei Út 11', 'Budapest, II.', NULL, NULL, '2022-07-20 10:31:16', '2022-07-20 10:31:16'),
(67, 'user', 'Farkas', 'Bence', 'tesztfarkasbence21@gmail.com', NULL, NULL, 'c334246cfc6455f1e084c7646a04f432', 0, '', '', NULL, NULL, NULL, 0, NULL, '', '', NULL, '289550c030aa0caf6b50fbd139cdaabf30b44bb0d85b4963f262acea214d60a89783215', '2022-07-20 10:35:36', NULL),
(68, 'user', 'Farkas', 'Bence', 'farkasbenceasd2@gmail.com', NULL, NULL, 'c334246cfc6455f1e084c7646a04f432', 0, '', '', NULL, NULL, NULL, 0, NULL, '', '', NULL, '37dd6a8e0a875b7836fcf38066aafd35198c40911961af78b83f22b5f92822158782961', '2022-07-20 10:43:19', NULL),
(69, 'user', 'Farkas', 'Bence', 'fasasdad@gmail.com', NULL, NULL, 'c334246cfc6455f1e084c7646a04f432', 0, '', '', NULL, NULL, NULL, 0, NULL, '', '', NULL, 'f50115ab47f6b0f1328f0e7ab565f2d8637b991cbde4f56302406a746b558d3d2174849', '2022-07-20 10:46:29', NULL),
(70, 'user', 'Farkas', 'Bence', 'fasasdadasda@gmail.com', NULL, NULL, 'c334246cfc6455f1e084c7646a04f432', 0, '', '', NULL, NULL, NULL, 0, NULL, '', '', NULL, 'bb33e65f70ef39780d5a7e6b270364d5f6a7dbe619a4d1fce43255bb95a5cbb07988089', '2022-07-20 10:49:10', NULL);

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `pizzas`
--
ALTER TABLE `pizzas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `url` (`url`);

--
-- A tábla indexei `sizes`
--
ALTER TABLE `sizes`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `toppings`
--
ALTER TABLE `toppings`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- AUTO_INCREMENT a táblához `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
